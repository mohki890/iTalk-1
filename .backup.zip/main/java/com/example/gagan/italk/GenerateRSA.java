package com.example.gagan.italk;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.util.Base64;
import android.util.Log;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Array;
import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.RSAPrivateKeySpec;
import java.security.spec.RSAPublicKeySpec;
import java.security.spec.X509EncodedKeySpec;

import javax.net.ssl.KeyManager;

/**
 * Created by gagan on 23/9/15.
 */
public class GenerateRSA extends AsyncTask<Void,Void,Void> {
    Context context;
    ProgressDialog pd;
    String privateKey,publicKey;

    static void generate(final Context con)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(con);
        builder.setTitle("Certificate Update");
        builder.setIcon(android.R.drawable.ic_dialog_alert);
        builder.setMessage("Do you really want to change your certificate, It may have initial effects. It's not a thing to be done occasionally");
        builder.setPositiveButton("Yes, I know what I'm doing",new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

                (new GenerateRSA(con)).execute();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.show();

    }
    GenerateRSA(Context con)
    {
        context = con;

    }
    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        pd = new ProgressDialog(context);
        pd.setTitle("Please Wait");
        pd.setMessage("Updating Certificate");
        pd.show();

        Toast.makeText(context,"Generating Keys",Toast.LENGTH_SHORT).show();


    }

    @Override
    protected Void doInBackground(Void... voids) {

        try {
            generateKeys();



            AppToServer.updateMyPublicCertificate(context,privateKey,publicKey);

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } finally {
           pd.dismiss();
        }

        return null;
    }
    static void updateInPref(Context context,String pri,String pub)
    {
        SharedPreferences preferences= PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor=preferences.edit();
        editor.putString(BackgroundService.getMyID()+"_privateKey", pri);
        editor.putString(BackgroundService.getMyID()+"_publicKey", pub);
        BackgroundService.initilizeDecrypter(context);

        editor.commit();
    }

    String getStringKey(BigInteger mod,BigInteger exp)
    {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        try {
            ObjectOutputStream oos = new ObjectOutputStream(bo);
            oos.writeObject(mod);
            oos.writeObject(exp);
            oos.flush();
            return bo.toString();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }
    static PrivateKey getPrivateKey(String str)
    {
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(Base64.decode(str,Base64.DEFAULT));
        KeyFactory keyFactory = null;
        try {
            keyFactory = KeyFactory.getInstance("RSA");
            PrivateKey privateKey1 = keyFactory.generatePrivate(keySpec);
            return privateKey1;
        } catch (Exception e) {
            e.printStackTrace();
            Log.e(">>>>>>>>",e.toString());
        }

        /*
        BigInteger mod;
        BigInteger exp;
        try {
            ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(str.getBytes()));
            mod = (BigInteger) ois.readObject();
            exp = (BigInteger) ois.readObject();
            RSAPrivateKeySpec rsaPrivateKeySpec = new RSAPrivateKeySpec(mod,exp);
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            PrivateKey privateKey1 = keyFactory.generatePrivate(rsaPrivateKeySpec);
            return privateKey1;
        } catch (Exception e)
        {
            Log.e(">>>>>>>>>>>>>>>", e.toString());
        }*/
       /* catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
        }*/
        return null;
    }
    static PublicKey getPublicKey(String str)
    {
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.decode(str,Base64.DEFAULT));
        KeyFactory keyFactory = null;
        try {
            keyFactory = KeyFactory.getInstance("RSA");
            PublicKey publicKey1 = keyFactory.generatePublic(keySpec);
            return publicKey1;
        }  catch (Exception e) {
            e.printStackTrace();
            Log.e(">>>>>>>>", e.toString());
        }
      /*  BigInteger mod;
        BigInteger exp;
        try {
            ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(str.getBytes()));
            mod = (BigInteger) ois.readObject();
            exp = (BigInteger) ois.readObject();
            RSAPublicKeySpec rsaPublicKeySpec = new RSAPublicKeySpec(mod,exp);
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            PublicKey publicKey1 = keyFactory.generatePublic(rsaPublicKeySpec);
            return publicKey1;
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
        }
    */    return null;
    }
    void generateKeys() throws NoSuchAlgorithmException {
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
        keyPairGenerator.initialize(1024);
        KeyPair keyPair = keyPairGenerator.genKeyPair();
        PrivateKey privateKey = keyPair.getPrivate();
        PublicKey publicKey = keyPair.getPublic();

        KeyFactory keyFactory = KeyFactory.getInstance("RSA");

        RSAPublicKeySpec rsaPublicKeySpec = null;
        try {
            rsaPublicKeySpec = keyFactory.getKeySpec(publicKey,RSAPublicKeySpec.class);
        RSAPrivateKeySpec rsaPrivateKeySpec = keyFactory.getKeySpec(privateKey,RSAPrivateKeySpec.class);

        this.privateKey = Base64.encodeToString(privateKey.getEncoded(),Base64.DEFAULT);//getStringKey(rsaPrivateKeySpec.getModulus(),rsaPrivateKeySpec.getPrivateExponent());
        this.publicKey  = Base64.encodeToString(publicKey.getEncoded(),Base64.DEFAULT);//getStringKey(rsaPublicKeySpec.getModulus(),rsaPublicKeySpec.getPublicExponent());

          Log.e(">>>>>>>>>>>>> ",","+this.publicKey);
            PublicKey tPrivateKey1 = getPublicKey(this.publicKey);
            if(!tPrivateKey1.equals(privateKey))
                {
                    Log.e(">>>>>>>>>>>>>>","Currupted Key");
                    return;
                }
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
        }
        //Toast.makeText(context,privateKey.length+" "+publicKey.length,Toast.LENGTH_SHORT).show();

    }
    static void setUserPublicKey(Context context,String pub,int id)
    {
        SharedPreferences preferences= PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor=preferences.edit();
        editor.putString("publicUser_"+id, pub);

        editor.commit();

    }
    static String getUserPublicKey(Context context,int id)
    {
        SharedPreferences preferences= PreferenceManager.getDefaultSharedPreferences(context);
        return preferences.getString("publicUser_"+id,"");

    }
    static String getMyPrivateKey(Context context)
    {
        SharedPreferences preferences= PreferenceManager.getDefaultSharedPreferences(context);

        return preferences.getString(BackgroundService.getMyID()+"_privateKey","");


    }
    static String getMyPublicKey(Context context)
    {
        SharedPreferences preferences= PreferenceManager.getDefaultSharedPreferences(context);
        return preferences.getString(BackgroundService.getMyID()+"_publicKey","");


    }
}
