package com.example.gagan.italk;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.Binder;
import android.os.Environment;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.util.Pair;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;

/**
 * Created by gagan on 16/7/15.
 */
public class BackgroundService extends Service implements Runnable {
    int SLEEP_TIMER=1000;
    boolean isRunning;
    Thread t;



    public static UserRoom userRoom;
    public static BackgroundService myRef;
    private final IBinder binder=new ServiceBinder();
    private boolean isOnline=false;
    private int ONLINE_TESTER_TIMER=0,ONLINE_SYNC_TIMER=1,ONLINE_USERINFO_SYNCTIMER=0;
    private final int ONLINE_TESTER_TIMER_MAX=60,ONLINE_MAX_SYNC_TIMER_NA=30,ONLINE_MAX_SYNC_TIMER_A=1,ONLINE_MAX_USERINFO_SYNCTIMER=60;

    private int LAST_CHAT_MSG_ID=0,REQUEST_CHAT_MSGS=10;
    private static int AllUsersMAXLoadedID;
    private ArrayList<Pair<Integer,Pair<Integer,Integer>>> AllUsersLastId=new ArrayList<>();


    private static String uname="",nname="";
    private static int myID=-1;

    static ContentConversionDecrypt contentConversionDecrypt;


    public boolean getIsAppActive()
    {

        if(userRoom==null)
            return false;
        return true;
    }

    public static int getMyID(){return myID;}
    public static String getUname(){return  uname;}
    public static String getNname(){return  nname;}


    @Override
    public void onCreate() {
        super.onCreate();
        if(myRef!=null)
        {
            myRef.stopSelf();
        }
        myRef=this;
        startAlreadyLoggedIn();


    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        isRunning=false;
        //serviceThread.isRunning=false;
        //myRef=null;
    }
    public void getMyDetailsFromSharedPref()
    {
        getMyDetailsFromSharedPref(this);



    }
    public static void getMyDetailsFromSharedPref(Context con)
    {
        SharedPreferences preferences= PreferenceManager.getDefaultSharedPreferences(con);
        uname=preferences.getString("uname","");
        nname=preferences.getString("nname","");
        myID=preferences.getInt("id", -1);



    }

    @Override
    public IBinder onBind(Intent intent) {
        startAlreadyLoggedIn();
        return binder;
    }

    public static int getAllUsersMAXLoadedID() {
        return AllUsersMAXLoadedID;
    }


    class ServiceBinder extends Binder
    {
        public BackgroundService getSystemService()
        {
            return BackgroundService.this;
        }
    }
    static void initilizeDecrypter(Context con)
    {
        if(BackgroundService.contentConversionDecrypt==null)
            contentConversionDecrypt = new ContentConversionDecrypt(con.getApplicationContext());

        if(contentConversionDecrypt.initilize()!=ContentConversionDecrypt.SETKEY_DONE)
            contentConversionDecrypt = null;

    }
    public void startAlreadyLoggedIn()
    {
        getMyDetailsFromSharedPref();
        initilizeDecrypter(this);
        AllUsersMAXLoadedID=DB.getMaxUserID(this);
        updateLastChatMsg();
        Intent in=new Intent(this,UserRoom.class);
        in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(in);
        isRunning=false;
        //if(serviceThread!=null)
        //    serviceThread.isRunning=false;
        //serviceThread=new ServiceThread();
        startThread();

    }
  /*  public void startAlreadyLoggedInTwice()
    {
        AllUsersMAXLoadedID=DB.getMaxUserID(this);
        //MY_ID=AppToServer.getId();
        updateLastChatMsg();
        Intent in=new Intent(this,UserRoom.class);
        in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(in);

        //serviceThread=new ServiceThread();

    }*/
    public static void doLogout(UserRoom activity)
    {
        AppToServer.doLogout(activity,new Callable<Void>() {
            @Override
            public Void call() throws Exception {
                if(myRef!=null)
                    myRef.stopSelf();
                return null;

            }
        });
    }
    public int updateLastChatMsg()
    {
        DB dbhelper=new DB(this,DB.getDBNameFromA2S());
        SQLiteDatabase database= dbhelper.getReadableDatabase();
        Cursor cursor=database.rawQuery("SELECT max(" + DB.COL_CHAT_I + ") FROM " + DB.DB_TABLE_CHAT, null);
        if(cursor.moveToNext())
            LAST_CHAT_MSG_ID=cursor.getInt(0);
        database.close();
        Log.v("**************", "LSM " + LAST_CHAT_MSG_ID);
        return 0;
    }
    public void addChatMsgQuery(List<ContentValues> queries)
    {
        Log.v("**************","Chat Rows Added : "+queries.size());

        if(queries.size()==0) return;

        DB dbhelper=new DB(this,DB.getDBNameFromA2S());
        SQLiteDatabase database= dbhelper.getWritableDatabase();

        for(int i=0;i<queries.size();i++)
        {
                ContentValues cv = queries.get(i);
                if (contentConversionDecrypt != null)
                {
                    String txt = contentConversionDecrypt.decrypt(cv.getAsString(DB.COL_CHAT_TEXT));
                    if(txt==null) continue;;
                    cv.put(DB.COL_CHAT_TEXT, txt);
                }
            database.insert(DB.DB_TABLE_CHAT,null,queries.get(i));
        }
        database.close();
        int x=LAST_CHAT_MSG_ID;
        updateLastChatMsg();
        if(!getIsAppActive())
        {
            showNewMsgNotification(x);
        }

        ONLINE_SYNC_TIMER=1;    //Again Get More Queries

    }
    void showNewMsgNotification(int last_msg_id)
    {
/*     "Select U."+COL_USER_ID+",U."+COL_USER_USERNAME+",U."+COL_USER_NICKNAME+",C."+COL_CHAT_TEXT
                +",C."+COL_CHAT_TIME+",C."+COL_CHAT_TYPE+",C."+COL_CHAT_FILETYPE+",C."+COL_CHAT_MYID+" AS mine"
           */
      if(last_msg_id>=LAST_CHAT_MSG_ID) return;
     List list=DB.getNewMsgInfo(this,last_msg_id);


        for(int i=0;i<list.size();i++)
        {
            ArrayList<Object> ele= (ArrayList<Object>) list.get(i);
            String msg;
            if((int)ele.get(5)%2!=0)
                msg="You've received new messages.";
            else msg="Your message is send";
            Log.i("--------------","Msg Received "+ele.get(2));
            Intent in=new Intent(this,NotificationReceiver.class);
            in.putExtra("msg",msg);
            in.putExtra("ID",(int)ele.get(0));
            in.putExtra("uname",(String)ele.get(1));
            in.putExtra("nname",(String)ele.get(2));

            sendBroadcast(in);

        }
    }
    public void addAllUserQuery(List<ContentValues> queries)
    {
        Log.v("**************","AllUsers Rows Added : "+queries.size());

        if(queries.size()==0) return;

        DB dbhelper=new DB(this,DB.getDBNameFromA2S());
        SQLiteDatabase database= dbhelper.getWritableDatabase();
        if(AllUsersMAXLoadedID==0)
        {
            //If Initially NoData
            AllUsersLastId.clear();

        }
        for(int i=0;i<queries.size();i++) {
            database.insert(DB.DB_TABLE_USERS, null, queries.get(i));
            AllUsersMAXLoadedID=Math.max(AllUsersMAXLoadedID,queries.get(i).getAsInteger(DB.COL_USER_ID));
            AllUsersLastId.add(new Pair<>(queries.get(i).getAsInteger(DB.COL_USER_ID),new Pair<>(queries.get(i).getAsInteger(DB.COL_USER_LASTUPDATE),queries.get(i).getAsInteger(DB.COL_USER_DP))));

        }
        Log.e("********","USER F:"+queries.size());
        database.close();

        if(userRoom!=null)
            DB.setAllDetails(userRoom,userRoom.arrayAdapter);

    }
    public boolean isOnline()
    {
        return isOnline;
    }
    public void callDBChatSync()
    {
        AppToServer.syncChatDB(BackgroundService.this, LAST_CHAT_MSG_ID+1, REQUEST_CHAT_MSGS, new Callable<Void>() {
            @Override
            public Void call() throws Exception {
                Log.e("**********","ERROR IN syncChat");
                return null;
            }
        },new Callable<Void>()
        {
            @Override
            public Void call() throws Exception {

                ONLINE_SYNC_TIMER = -2;
                return null;
            };
        });
    }




    @Override
    public void run() {
        AppToServer.setMyInfo(BackgroundService.this, new Callable<Void>() {
            @Override
            public Void call() throws Exception {
                return null;
            }
        });

        while (isRunning)
        {
            try {
                if(ONLINE_TESTER_TIMER==0)
                {

                    AppToServer.testLoggedIn(BackgroundService.this,new Callable<Void>() {
                        @Override
                        public Void call() throws Exception {
                            isOnline=true;
                            return null;
                        }
                    },new Callable<Void>() {
                        @Override
                        public Void call() throws Exception {
                            isOnline=false;
                            return null;
                        }
                    });
                    ONLINE_TESTER_TIMER=ONLINE_TESTER_TIMER_MAX;
                }
                if(isOnline()) {
                    if (ONLINE_SYNC_TIMER == 0) {
                        ONLINE_SYNC_TIMER = -1;
                        callDBChatSync();


                    } else if (ONLINE_SYNC_TIMER > 0) ONLINE_SYNC_TIMER--;
                }
                ONLINE_TESTER_TIMER--;
                if(ONLINE_SYNC_TIMER==-2)
                {
                    if(getIsAppActive())
                        ONLINE_SYNC_TIMER=ONLINE_MAX_SYNC_TIMER_A;
                    else
                        ONLINE_SYNC_TIMER=ONLINE_MAX_SYNC_TIMER_NA;
                }

                if(ONLINE_USERINFO_SYNCTIMER==0)
                {

                    AppToServer.syncAllUserInfo(BackgroundService.this,AllUsersMAXLoadedID,new Callable<Void>() {
                        @Override
                        public Void call() throws Exception {
                            return null;
                        }
                    },new Callable<Void>() {
                        @Override
                        public Void call() throws Exception {
                            Log.v("-------","User Sync Was ran");
                            return null;
                        }
                    });

                    ONLINE_USERINFO_SYNCTIMER=ONLINE_MAX_USERINFO_SYNCTIMER;
                }
                ONLINE_USERINFO_SYNCTIMER--;


                t.sleep(SLEEP_TIMER);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }
    void startThread()
    {
        t=new Thread(this);
        isRunning=true;
        t.start();

    }

}
