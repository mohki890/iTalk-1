package com.example.gagan.italk;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Shader;
import android.os.Environment;
import android.widget.Toast;

import java.io.File;
import java.io.InputStream;
import java.util.concurrent.Callable;

public class AdditionalFunctions
{
    public static String getDP_URL(int id,boolean isThumb)
    {
        String url=AppToServer.getMainAdd()+"/data/dp/"+id;
        if(isThumb)url=AppToServer.getMainAdd()+"/data/dp/t_"+id;
        return  url;
    }
    public static void uploadFileDP(Activity activity,Bitmap bitmapImg, final Bitmap bitmapThumb, final Callable<Void> onSuccess) {
        if (bitmapImg == null || bitmapThumb == null) return;

        new Base64FromBitmap(1024 * 1024 * 5, activity, "FileSize Should be less 5MB") {
            @Override
            protected void onPostExecute(final String base64Image) {
                super.onPostExecute(base64Image);
                if (base64Image == null) return;
                //For Thumbnail

                new Base64FromBitmap(1024 * 500, activity, "FileSize Should be less 500KB") {
                    @Override
                    protected void onPostExecute(String base64Thumb) {
                        super.onPostExecute(base64Thumb);
                        if (base64Thumb == null) return;
                        AppToServer.uploadFileDPBase64(activity, base64Image, base64Thumb, onSuccess);
                    }
                }.execute(bitmapThumb);




            }
        }.execute(bitmapImg);
    }

    public static void uploadFileDB(final Activity activity,final int other_id, final File file, final Callable<Void> onSuccess, final Callable<Void> onFailure) {
        if (file == null ) return;
        Toast.makeText(activity, "Preparing Upload", Toast.LENGTH_SHORT).show();
        new Base64FromFile(1024 * 1024 * 10, activity, "FileSize Should be less 10MB") {

            @Override
            protected void onPostExecute(final String base64File) {
                super.onPostExecute(base64File);
                if (base64File == null) return;
                //For Thumbnail

                AppToServer.uploadFileDBBase64(activity,other_id,file.getName() ,base64File,1, onSuccess, onFailure);




            }
        }.execute(file);
    }

    public static void uploadFileDBstream(final Activity activity,final int other_id,final String filename, final InputStream is, final Callable<Void> onSuccess, final Callable<Void> onFailure) {
        Toast.makeText(activity, "Preparing Upload", Toast.LENGTH_SHORT).show();
        new Base64FromStream(1024 * 1024 * 10, activity, "FileSize Should be less 10MB") {

            @Override
            protected void onPostExecute(final String base64File) {
                super.onPostExecute(base64File);
                if (base64File == null) return;
                AppToServer.uploadFileDBBase64(activity,other_id,filename ,base64File,1, onSuccess, onFailure);
         }
        }.execute(is);
    }

    static Bitmap giveMeCirculaImage(Bitmap b,float scale,boolean addShadow) {
        int width = b.getWidth(), height = b.getHeight();

        Bitmap cropped_bitmap;
        if (width > height) {
            cropped_bitmap = Bitmap.createBitmap(b,
                    (width / 2) - (height / 2), 0, height, height);
        } else {
            cropped_bitmap = Bitmap.createBitmap(b, 0, (height / 2)
                    - (width / 2), width, width);
        }

        BitmapShader shader = new BitmapShader(cropped_bitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);

        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setShader(shader);

        height = cropped_bitmap.getHeight();
        width = cropped_bitmap.getWidth();

        Bitmap mCanvasBitmap = Bitmap.createBitmap(width, height,
                Bitmap.Config.ARGB_8888);

        Canvas canvas = new Canvas(mCanvasBitmap);

        canvas.drawCircle(width / 2, height / 2, width / 2, paint);
        canvas.scale(scale,scale);
        if(addShadow) {
       /*     Paint shadow = new Paint();
            paint.setShadowLayer(width / 2, width / 2 / 8, width / 2 / 8, Color.GREEN);
            canvas.drawCircle(width / 2, width / 2,width/2, shadow);
        */
        }

        return mCanvasBitmap;
    }

    static  File getiTalkDir()
    {
        File dir= Environment.getExternalStorageDirectory();
        File folname=new File(dir.getAbsolutePath()+"/iTalk");
        folname.mkdirs();
        return folname;
    }
    static  File getiTalkDirAlbum(String album)
    {
        File dir= Environment.getExternalStorageDirectory();
        File folname=new File(dir.getAbsolutePath()+"/iTalk/"+album);
        folname.mkdirs();
        return folname;
    }
    public static File getiTalkDPDir()
    {
        File dpFolder = new File(getiTalkDir().getAbsolutePath()+"/DP");
        dpFolder.mkdirs();
        return dpFolder;
    }

    static Bitmap giveMeCircularImage(Bitmap b,float scale,boolean addShadow) {
        int width = b.getWidth(), height = b.getHeight();

        Bitmap cropped_bitmap;
        if (width > height) {
            cropped_bitmap = Bitmap.createBitmap(b,
                    (width / 2) - (height / 2), 0, height, height);
        } else {
            cropped_bitmap = Bitmap.createBitmap(b, 0, (height / 2)
                    - (width / 2), width, width);
        }

        BitmapShader shader = new BitmapShader(cropped_bitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);

        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setShader(shader);

        height = cropped_bitmap.getHeight();
        width = cropped_bitmap.getWidth();

        Bitmap mCanvasBitmap = Bitmap.createBitmap(width, height,
                Bitmap.Config.ARGB_8888);

        Canvas canvas = new Canvas(mCanvasBitmap);

        canvas.drawCircle(width / 2, height / 2, width / 2, paint);
        canvas.scale(scale,scale);
        if(addShadow) {
       /*     Paint shadow = new Paint();
            paint.setShadowLayer(width / 2, width / 2 / 8, width / 2 / 8, Color.GREEN);
            canvas.drawCircle(width / 2, width / 2,width/2, shadow);
        */
        }

        return mCanvasBitmap;
    }

}
