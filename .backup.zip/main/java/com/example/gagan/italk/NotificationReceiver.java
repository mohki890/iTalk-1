package com.example.gagan.italk;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;

/**
 * Created by gagan on 14/8/15.
 */
public class NotificationReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        int id = intent.getIntExtra("id",-1);
        String uname = intent.getStringExtra("uname"),nname = intent.getStringExtra("nname");
        NotificationCompat.Builder builder=new NotificationCompat.Builder(context)
                .setContentTitle("iTalk")
                .setContentText((String) nname + " (" + uname + ")")
                .setSubText(intent.getStringExtra("msg"))
                .setSmallIcon(R.drawable.no_dp)
                .setAutoCancel(true);

        File fname=new File(AdditionalFunctions.getiTalkDPDir(),"DP"+id);
        Bitmap b=null;
        if(fname.exists())
        {
          b =  BitmapFactory.decodeFile(fname.getAbsolutePath());
        }
        if (b != null) {
                builder.setLargeIcon(b);
                builder.setSmallIcon(R.drawable.online_circle);
        }

        Intent in=new Intent(context,chatRoom.class);
        in.putExtra("other_id", id);
        in.putExtra("other_uname", uname);
        in.putExtra("other_nname", nname);

        PendingIntent pendingIntent=PendingIntent.getActivity(context,0,in,PendingIntent.FLAG_UPDATE_CURRENT);
        builder.setContentIntent(pendingIntent);
        NotificationManager notificationManager=(NotificationManager)context.getSystemService(context.NOTIFICATION_SERVICE);

        notificationManager.notify(id,builder.build());



    }
}
