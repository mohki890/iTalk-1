package com.example.gagan.italk;

import android.content.Context;
import android.util.Base64;
import android.util.Log;
import android.util.Pair;
import android.widget.Toast;

import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

/**
 * Created by gagan on 17/5/15.
 */
public class ContentConversion {
    //length of key in AES
    //Do we need to generate Key Everytime(Speed and Security)
    private static String LOG=ContentConversion.class.getSimpleName();


    /***Success and Error Code ****/
    public static final int SETKEY_DONE=0;
    public static final int SETKEY_NULL=1;
    public static final int SETKEY_MAXDIGITNOTMATCH=2;
    public static final int SETKEY_NOSUCHALGO=3;
    public static final int SETKEY_NOSUCHPADDING=4;
    public static final int SETKEY_INVALIDKEY_MINE=5;
    public static final int SETKEY_INVALIDKEY_OTHER=6;



    private String enc_type="RSA";
    private final int key_size=1024;

    private Cipher cipherE,cipherMe;
    private boolean isOk=false;

    Context context;
    ContentConversion(Context context)
    {
    this.context = context;
    }


    public int initilize(int otherId)
    {
      //,GenerateRSA.getMyPrivateKey(context)
      return setKey(GenerateRSA.getUserPublicKey(context, otherId));

    }

    //Methods
    public int setKey(String keyOther)
    {
        Log.e(LOG,"Set Key Start ");
        if(keyOther==null) return SETKEY_NULL;
        if(keyOther=="") return SETKEY_NULL;

        PublicKey publicKey         = GenerateRSA.getPublicKey(keyOther);
        PublicKey publicKeyMine     = GenerateRSA.getPublicKey(GenerateRSA.getMyPublicKey(context));
        isOk=false;
        try {
            cipherE=Cipher.getInstance(enc_type);
            cipherMe=Cipher.getInstance(enc_type);
        } catch (NoSuchAlgorithmException e) {

            Log.e(LOG,e.toString());
            return SETKEY_NOSUCHALGO;
        } catch (NoSuchPaddingException e) {
            Log.e(LOG,e.toString());
            return SETKEY_NOSUCHPADDING;
        }
        if(cipherE==null)
            return SETKEY_NULL;
        if( publicKey==null)
            return SETKEY_NULL;
        if(cipherMe==null)
            return SETKEY_NULL;
        if( publicKeyMine==null)
            return SETKEY_NULL;



        try {
            cipherE.init(Cipher.ENCRYPT_MODE,publicKey);
            cipherMe.init(Cipher.ENCRYPT_MODE,publicKeyMine);
        } catch (Exception e) {
            Log.e(LOG,e.toString());
            return SETKEY_INVALIDKEY_OTHER;
        }
        isOk=true;
        Log.e(LOG,"Set Key Done");

        return SETKEY_DONE;

    }


    public Pair<String,String> encrypt(String data)
    {
        if(data==null) {
            Log.e(LOG,"Encrypt : Data is NULL");

            return null;
        }
        if(isOk)
        {

            try {
                byte[] b= cipherE.doFinal(data.getBytes());
                String s=new String(Base64.encode(b,Base64.DEFAULT)); //RFC 2045
                byte[] b2= cipherMe.doFinal(data.getBytes());
                String s2=new String(Base64.encode(b2,Base64.DEFAULT)); //RFC 2045
                return  new Pair<String,String>(s,s2);

            } catch (IllegalBlockSizeException e) {
                Log.e(LOG,e.toString());
                return null;
            } catch (BadPaddingException e) {
                Log.e(LOG,e.toString());
                return null;
            }
       }
        Log.e(LOG,"Encrypt Returning NULL, isOK="+isOk);

        return null;
    }


}

class ContentConversionDecrypt {
    //length of key in AES
    //Do we need to generate Key Everytime(Speed and Security)
    private static String LOG=ContentConversionDecrypt.class.getSimpleName();


    /***Success and Error Code ****/
    public static final int SETKEY_DONE=0;
    public static final int SETKEY_NULL=1;
    public static final int SETKEY_MAXDIGITNOTMATCH=2;
    public static final int SETKEY_NOSUCHALGO=3;
    public static final int SETKEY_NOSUCHPADDING=4;
    public static final int SETKEY_INVALIDKEY_MINE=5;
    public static final int SETKEY_INVALIDKEY_OTHER=6;



    private String enc_type="RSA";
    private final int key_size=1024;
    private Cipher cipher;
    private boolean isOk=false;

    Context context;
    ContentConversionDecrypt(Context context)
    {
        this.context = context;
    }


    public int initilize()
    {

        return setKey(GenerateRSA.getMyPrivateKey(context));

    }

    //Methods
    public int setKey(String keyMine)
    {

        if(keyMine==null) return SETKEY_NULL;
        if(keyMine=="") return SETKEY_NULL;



        PrivateKey privateKey   = GenerateRSA.getPrivateKey(keyMine);


        isOk=false;
        try {
            cipher=Cipher.getInstance(enc_type);
        } catch (NoSuchAlgorithmException e) {

            Log.e(LOG,e.toString());
            return SETKEY_NOSUCHALGO;
        } catch (NoSuchPaddingException e) {
            Log.e(LOG,e.toString());
            return SETKEY_NOSUCHPADDING;
        }

        if(cipher==null)
            return SETKEY_NULL;
        if(privateKey==null)
            return SETKEY_NULL;


        try {
            cipher.init(Cipher.DECRYPT_MODE,privateKey);
        } catch (InvalidKeyException e) {
            Log.e(LOG,">>>>>>>>>>>>>>>>>> " +e.toString());
            return SETKEY_INVALIDKEY_MINE;
        }

        isOk=true;
        Log.e(LOG,"Set Key Done");

        return SETKEY_DONE;

    }


    public String decrypt(String enc)
    {
        if(true)
           ;// return enc;
        if(enc==null) return null;
        if(isOk)
        {
            byte[] dec=null;
            try {
                dec= cipher.doFinal(Base64.decode(enc,Base64.DEFAULT));
            } catch (Exception e) {
                return null;
            }
            if(dec==null) return null;
            return new String(dec);
        }
        return null;
    }


}
