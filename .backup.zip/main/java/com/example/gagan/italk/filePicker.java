package com.example.gagan.italk;

import android.app.Activity;
import android.content.ContentProvider;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.util.Pair;
import android.view.View;
import android.widget.Toast;

import java.io.InputStream;
import java.util.Date;
import java.util.concurrent.Callable;

/**
 * Created by gagan on 23/7/15.
 */
public class filePicker {
    public static final int RC_IMAGE=2;
    public static final int RC_VIDEO=1;
    public static final int RC_GENERAL=0;
    public static final int RC_LIVECAPTURE=3;


    Activity activity;
    filePicker(Activity activity)
    {
        this.activity=activity;
    }
    public void pickImage()
    {
        Intent intent=new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        activity.startActivityForResult(Intent.createChooser(intent, "Pick File"), RC_IMAGE);
    }

    public Object onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == RC_IMAGE || requestCode == RC_VIDEO ||requestCode == RC_GENERAL ) {

            if (resultCode == Activity.RESULT_OK) {
                try
                {

                    Uri path=data.getData();
                    InputStream is=activity.getContentResolver().openInputStream(path);
                    Cursor cursor=activity.getContentResolver().query(path,null,null,null,null);
                    String str="";
                    if(cursor!=null && cursor.moveToFirst())
                    {
                       str= cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                        cursor.close();
                    }

                    if(str.isEmpty())
                    {
                        str=String.valueOf((new Date()).getTime());
                    }

                    if(is==null) return null;
                    return new Pair<String,InputStream>(str,is);
                }catch (Exception e){
                    Toast.makeText(activity,"Some Exception Occured!\n"+e.toString(),Toast.LENGTH_LONG).show();
                }
            }
            else
            if(resultCode == Activity.RESULT_CANCELED)
            {
                Toast.makeText(activity,"Cancelled!",Toast.LENGTH_SHORT).show();
            }
        }
        return null;

    }


}
