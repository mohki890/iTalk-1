package com.example.gagan.italk;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import java.sql.SQLData;
import java.sql.SQLInput;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by gagan on 3/7/15.
 */
public class DB extends SQLiteOpenHelper {
    private static String DB_NAME="iTalk.db";
    public final static int DB_VERSION=1;


    public final static String DB_TABLE_USERS="USERS";
    public final static String DB_TABLE_CHAT="CHAT";
    public final static String DB_VIEW_LASTESTMSG="LATESTMSG";

    public final static String COL_CHAT_I="i";
    public final static String COL_CHAT_MYID="myid";
    public final static String COL_CHAT_ID="id";
    public final static String COL_CHAT_OTHER="other";
    public final static String COL_CHAT_TYPE="type";
    public final static String COL_CHAT_TEXT="text";
    public final static String COL_CHAT_FILETYPE="filetype";
    public final static String COL_CHAT_TIME="time";

    public final static String COL_USER_LASTUPDATE="uid";
    public final static String COL_USER_ID="id";
    public final static String COL_USER_USERNAME="uname";
    public final static String COL_USER_NICKNAME="nname";
    public final static String COL_USER_LASTLOGIN="lastlogin";
    public final static String COL_USER_DP="dpid";



    public static String getDBName(int UserId)
    {
        return "iTalk"+UserId+".db";
    }
    public static String getDBNameFromA2S()
    {
        return getDBName(BackgroundService.getMyID());
    }

    Context context;

    public DB(Context context,String db_file) {
        super(context,db_file, null, DB_VERSION);
        this.context=context;

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        createAllTables(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

    protected void createAllTables(SQLiteDatabase db)
    {
        String query_createChat="CREATE TABLE "+DB_TABLE_CHAT+" (" +
                COL_CHAT_I+" int,"+
                COL_CHAT_MYID+" int," +
                COL_CHAT_ID+" int," +
                COL_CHAT_TYPE+" tinyint," +
                COL_CHAT_TEXT+" text," +
                COL_CHAT_FILETYPE+" tinyint," +
                COL_CHAT_OTHER+" int," +
                COL_CHAT_TIME+" timestamp);";
        String query_createUsers="CREATE TABLE "+DB_TABLE_USERS+" (" +
                COL_USER_LASTUPDATE + " int,"+
                COL_USER_ID+" int NOT NULL UNIQUE," +
                COL_USER_USERNAME+" varchar(100)," +
                COL_USER_NICKNAME+" varchar(100)," +
                COL_USER_DP+" int," +
                COL_USER_LASTLOGIN+" timestamp);";
        String query_createViewLastMsg="CREATE VIEW "+DB_VIEW_LASTESTMSG+" AS "+
                "Select U."+COL_USER_ID+",U."+COL_USER_USERNAME+",U."+COL_USER_NICKNAME+",C."+COL_CHAT_TEXT
                +",C."+COL_CHAT_TIME+",C."+COL_CHAT_TYPE+",C."+COL_CHAT_FILETYPE+",C."+COL_CHAT_MYID+" AS mine, C."+COL_CHAT_I+" AS Cindex"
                +" FROM "+DB_TABLE_USERS
                +" as U JOIN "+DB_TABLE_CHAT+" as C ON C."+COL_CHAT_OTHER+"=U."+COL_USER_ID
                +" WHERE C."+COL_CHAT_ID+"=("
                +   "SELECT max(IC."+COL_CHAT_ID+") FROM "+DB_TABLE_CHAT+" AS IC WHERE IC."+COL_CHAT_OTHER+"=C."+COL_CHAT_OTHER+" GROUP BY IC."+COL_CHAT_MYID+" HAVING IC."+COL_CHAT_MYID+"=C."+COL_CHAT_MYID
                +") GROUP BY C."+COL_CHAT_OTHER+" ORDER BY "+COL_CHAT_I+" DESC;";
        db.execSQL(query_createChat);
        db.execSQL(query_createUsers);
        db.execSQL(query_createViewLastMsg);
        //Toast.makeText(context,"TABLES CREATED",Toast.LENGTH_LONG).show();


    }

    public static void getChat(final chatRoom activity, int other_id,int last_message_min,int last_message_max, final boolean isNewMessage)
        {
            int latestmsg=0;
            Log.v("++++++++", "Request Chat Content");
            String filter=COL_CHAT_OTHER+"="+other_id+" AND "+COL_CHAT_MYID+"="+BackgroundService.getMyID();
            DB dbhelper=new DB(activity,getDBNameFromA2S());
            SQLiteDatabase database= dbhelper.getReadableDatabase();
            String whereClause;
            if(last_message_max==-1 && last_message_min==-1)
            {
                Cursor cursor=database.rawQuery("SELECT max("+COL_CHAT_ID+") FROM "+DB_TABLE_CHAT+" WHERE "+filter,null);
                if(cursor.moveToNext())
                    latestmsg=cursor.getInt(0);

                last_message_min=latestmsg-20;
                //Toast.makeText(activity,"Read MSG Me:"+BackgroundService.getMyID()+" Other:"+other_id+"\n"+latestmsg,Toast.LENGTH_SHORT).show();

                whereClause=filter+ " AND "+COL_CHAT_ID+">="+last_message_min;

            }
            else if(last_message_max<0)
            {
                whereClause=filter+" AND "+COL_CHAT_ID+">="+last_message_min;
            } else {
                whereClause=COL_CHAT_ID+" BETWEEN "+last_message_min+" AND "+last_message_max+" AND "+filter;

            }

            String columns[]={COL_CHAT_ID,COL_CHAT_TYPE,COL_CHAT_FILETYPE,COL_CHAT_TEXT,COL_CHAT_TIME};
            Log.v("**********",">> "+whereClause);
            //Cursor cursor=database.query(true,DB.DB_TABLE_CHAT,columns,whereClause,null,null,null,COL_CHAT_ID,limit);
            Cursor cursor=database.rawQuery("SELECT "+COL_CHAT_I+","+COL_CHAT_ID+","+COL_CHAT_TYPE+","+COL_CHAT_FILETYPE+","+COL_CHAT_TEXT+","+COL_CHAT_TIME+" FROM "+DB_TABLE_CHAT+" WHERE "+whereClause+" ORDER BY "+COL_CHAT_ID,null);
            ArrayList t_id=new ArrayList<Integer>();
            ArrayList t_filetype=new ArrayList<Integer>();
            ArrayList t_type=new ArrayList<Integer>();
            ArrayList t_text=new ArrayList<String>();
            ArrayList t_time=new ArrayList<String>();

            int c=0;
            while (cursor.moveToNext())
            {
                int id = cursor.getInt(1);
                int type = cursor.getInt(2);
                int filetype = cursor.getInt(3);
                String text = cursor.getString(4);
                String time = cursor.getString(5);
                if(text==null) continue;
                t_id.add(id);
                t_type.add(type);
                t_text.add(text);
                t_time.add(time);
                t_filetype.add(filetype);
                Log.v("++++++++ Txt", text);
                Log.v("******Row",id+" "+type+" "+filetype+" "+text+" "+time);
                c++;
            }
            Log.v("++++++++", c+"rows returned");

            database.close();

            activity.setMsgReceived(t_id, t_type, t_text, t_time, t_filetype, isNewMessage);


        }

    public static void setAllDetails(final UserRoom userRoom, final CustomAdapterUserRoomLV arrayAdapter) {
        //arrayAdapter.clear();
        DB dbhelper=new DB(userRoom,getDBNameFromA2S());
        SQLiteDatabase database= dbhelper.getReadableDatabase();
        final Cursor cursor = database.rawQuery("SELECT * FROM " + DB_VIEW_LASTESTMSG + " ;#WHERE mine=" + BackgroundService.getMyID(), null);

        int c = 0;
        if (cursor != null)
            while (cursor.moveToNext()) {
                final userinfo_element ue = new userinfo_element(cursor.getString(1), cursor.getString(2), cursor.getInt(0), false, null, cursor.getString(3), cursor.getInt(6), (cursor.getInt(5) % 2 == 0) ? false : true);
                ue.setLastMsgTime(cursor.getString(4));
                final int pos = arrayAdapter.getPositionById(cursor.getInt(0));
                if (pos < 0)
                    userRoom.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            arrayAdapter.add(ue);
                        }});
                else {
                    userinfo_element item = arrayAdapter.getItem(pos);
                    item.setLastMessage(cursor.getString(3), (cursor.getInt(5) % 2 == 0) ? false : true, cursor.getInt(6), cursor.getString(4));
                }
                c++;
            }
        Log.v("-------", "Users Added :" + c);
        database.close();
        if (c != 0)
            userRoom.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    arrayAdapter.notifyDataSetChanged();
                    userRoom.sortAdapter();
                }
            });


    }
    public static List getNewMsgInfo(Context context,int LAST_CHAT_MSG_ID) {

        DB dbhelper=new DB(context,getDBNameFromA2S());
        SQLiteDatabase database= dbhelper.getReadableDatabase();
        Cursor cursor = database.rawQuery("SELECT * FROM " + DB_VIEW_LASTESTMSG + " WHERE Cindex >"+LAST_CHAT_MSG_ID, null);
        ArrayList list=new ArrayList();
        if (cursor != null)
            while (cursor.moveToNext()) {
                ArrayList<Object> ele=new ArrayList<>();
                ele.add(cursor.getInt(0));
                ele.add(cursor.getString(1));
                ele.add(cursor.getString(2));
                ele.add(cursor.getString(3));
                ele.add(cursor.getString(4));
                ele.add(cursor.getInt(5));
                ele.add(cursor.getInt(6));
                list.add(ele);
            }
         database.close();
        return list;

    }
    public static int getMaxUserID(Context context) {


        DB dbhelper=new DB(context,getDBNameFromA2S());
        SQLiteDatabase database= dbhelper.getReadableDatabase();
        Cursor cursor=database.rawQuery("SELECT max("+COL_USER_ID+") FROM "+DB_TABLE_USERS+"",null);

        int max=0;
        if(cursor!=null)
            if (cursor.moveToNext())
                max=cursor.getInt(0);

        database.close();
        return max;
    }
    public static String escapeChar(String str)
    {
        String s=new String(str);
        String[] toBeEscaped={"\\","'","\""};
        for (int i = 0; i < toBeEscaped.length; i++) {
            s=s.replace(toBeEscaped[i],"\\"+toBeEscaped[i]);
        }
        return str;
    }


    }
